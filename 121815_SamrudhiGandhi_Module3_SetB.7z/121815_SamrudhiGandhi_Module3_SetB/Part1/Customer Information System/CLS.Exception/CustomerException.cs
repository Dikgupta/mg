﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLS.Exception
{
    /// <summary>
    /// Class to throw custom exception
    /// Author: Samrudhi Gandhi
    /// Date Modified: 14th march 2017
    /// Version No:1.0
    /// </summary>
    public class CustomerException : ApplicationException
    {
         // default constructor 
        public CustomerException() 
           : base()
        { }

        //parameterized constructor
        public CustomerException(string message) 
             : base(message)
        { }
    }
}
