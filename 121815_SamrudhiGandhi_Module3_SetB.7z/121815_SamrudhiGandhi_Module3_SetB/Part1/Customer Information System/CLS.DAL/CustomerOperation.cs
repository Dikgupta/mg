﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;     //Reference for ConfigurationManager
using System.Data;
using System.Data.SqlClient;    //Reference for Sql operations
using CLS.Entity;               //Reference form Entity Class
using CLS.Exception;            //Reference form Exception Class


namespace CLS.DAL
{
    /// <summary>
    /// Class containing database code
    /// Author: Samrudhi Gandhi
    /// Date Modified: 14th march 2017
    /// Version No:1.0
    /// </summary>
    public class CustomerOperation
    {
        SqlConnection connection;
        SqlDataReader reader;

        public CustomerOperation()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["custconn"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Method to add Customer record
        /// Author: Samrudhi Gandhi
        /// Date Modified: 14th march 2017
        /// Version No:1.0
        /// </summary>
        /// <param name="empObj"></param>
        /// <returns>bool</returns>
       public bool AddEmployeeRecord(Customer custObj)
        {
            try
            {
                bool custAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddedCustomerDetails121815", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                //cmdAdd.Parameters.AddWithValue("@CustomerID", custObj.CustomerID);
                cmdAdd.Parameters.AddWithValue("@CustomerName", custObj.CustomerName);
                cmdAdd.Parameters.AddWithValue("@City", custObj.City);
                cmdAdd.Parameters.AddWithValue("@Country", custObj.Country);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    custAdded = true;
                return custAdded;
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

       /// <summary>
       /// Method to return All Customer information
       /// Author: Samrudhi Gandhi
       /// Date Modified: 14th march 2017
       /// Version No: 
       /// </summary>
       /// <returns>DataTable</returns>
       public DataTable GetAllCustomerRecord()
       {

           try
           {
               SqlCommand cmd = new SqlCommand();
               cmd.CommandType = CommandType.StoredProcedure;
               cmd.CommandText = "getCustomer_121815";
               cmd.Connection = connection;
               if (connection.State == ConnectionState.Closed)

                   connection.Open();

               SqlDataReader dr = cmd.ExecuteReader();

               DataTable custTable = new DataTable();
               custTable.Load(dr);

               return custTable;
           }
           catch (CustomerException)
           {
               throw;
           }
           catch (SqlException)
           {
               throw;
           }
           catch (SystemException)
           {
               throw;
           }
           finally
           {
               connection.Close();
           }
       }

          
       }
    }

