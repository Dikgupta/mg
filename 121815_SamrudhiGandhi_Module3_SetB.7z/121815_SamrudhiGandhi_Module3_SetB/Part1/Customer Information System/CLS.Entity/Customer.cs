﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLS.Entity
{
    /// <summary>
    /// Entity to store Customer Information
    /// Author: Samrudhi Gandhi
    /// Date Modified: 14th march 2017
    /// Version No:1.0
    /// </summary>
    public class Customer
    {
        // Property to store and retrieve CustomerID
        public int CustomerID { get; set; }

        // Property to store and retrieve CustomerName
        public string CustomerName { get; set; }

        // Property to store and retrieve City
        public string City { get; set; }

        // Property to store and retrieve Country
        public string Country { get; set; }


    }
}
