﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Configuration;     //Reference for ConfigurationManager
using System.Data;
using System.Data.SqlClient;    //Reference for Sql operations
using CLS.Entity;               //Reference form Entity Class
using CLS.Exception;            //Reference form Exception Class
using CLS.DAL;                  //Reference form DAL Class

namespace CLS.BL
{   /// <summary>
    /// Class to validate Customer Record
    /// Author: Samrudhi Gandhi
    /// Date Modified: 14th march 2017
    /// </summary>
    public class CustomerVaildation
    {
        CustomerOperation cust = new CustomerOperation();
        /// <summary>
        /// Method to validate Customer record
        /// Author:Samrudhi Gandhi
        /// Date Modified: 14th march 2017
        /// version:1.0
        /// </summary>
        /// <param name="empObj"></param>
        /// <returns>bool</returns>
        public bool ValidateEmployeeRecord(Customer custObj)
        {
            bool validCustomer = true;

            StringBuilder sb = new StringBuilder();
            if (custObj.CustomerName.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Name is required.");
            }
            if (custObj.Country.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Country Name is required.");
            }
            if (custObj.City.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "City Name is required.");
            }
            else if (custObj.City.ToLower() != "pune" && custObj.City.ToLower() != "mumbai" && custObj.City.ToLower() != "bangalore")
            {
                sb.Append("City should be either Pune or Mumbai or Bangalore\n"); 
                validCustomer = false;
            }
            if (validCustomer == false)
            {
                throw new CustomerException(sb.ToString());
            }
            return validCustomer;
        }

        /// <summary>
        /// Method to add Customer record
        /// Author:Samrudhi Gandhi
        /// Date Modified: 14th march 2017
        /// version:1.0
        /// </summary>
        /// <param name="empObj"></param>
        /// <returns>bool</returns>
        public bool AddEmployeeRecord(Customer custObj)
        {
            bool custAdded = false;
            if (ValidateEmployeeRecord(custObj))
                custAdded = cust.AddEmployeeRecord(custObj);
            return custAdded;
        }
        /// <summary>
        /// Method to return All Customer information
        /// Author: Samrudhi Gandhi
        /// Date Modified: 14th march 2017
        /// Version No: 
        /// </summary>
        /// <param name="guestID"></param>
        /// <returns>DataTable</returns>

        public DataTable GetAllCustomerRecord()
        {

            try
            {
                DataTable custTable = cust.GetAllCustomerRecord();
                return custTable;
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }

        }
    }
}
