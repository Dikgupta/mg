﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CLS.BL;    //Reference form BL Class

namespace CIS.PL
/// <summary>
/// Return All Customer information
/// Author: Samrudhi Gandhi
/// Date Modified: 14th march 2017
/// Version No: 1.0
/// </summary>
{
    public partial class DisplayDetails : Form
    {
        CustomerVaildation custvaild = new CustomerVaildation();

        public DisplayDetails()
        {
            InitializeComponent();
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnDispalyGrid_Click(object sender, EventArgs e)
        {
            DataTable custTable = new DataTable();

            custTable = custvaild.GetAllCustomerRecord();

            dataGridView.DataSource = custTable;

        }
    }
}
