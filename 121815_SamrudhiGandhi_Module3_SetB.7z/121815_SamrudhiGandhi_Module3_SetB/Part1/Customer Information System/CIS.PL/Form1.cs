﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;    //Reference for Sql operations
using CLS.Entity;               //Reference form Entity Class
using CLS.Exception;            //Reference form Exception Class
using CLS.BL;                   //Reference form BL Class


namespace CIS.PL
{
    /// <summary>
    /// Author: Samrudhi Gandhi
    /// Date Modified: 14th march 2017
    /// Version No: 1.0
    /// </summary>
    public partial class Form1 : Form
    {
        CustomerVaildation custvaild = new CustomerVaildation();

        public Form1()
        {
            InitializeComponent();
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Customer custObj = new Customer();

                custObj.CustomerName = txtName.Text;
    
                custObj.Country = comboCountry.Text;
                custObj.City = combocity.Text;


                bool custAdded = custvaild.AddEmployeeRecord(custObj);
                if (custAdded)
                    MessageBox.Show("Customer Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add Customer record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            var myForm = new DisplayDetails();
            myForm.Show();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             string connectionString = ConfigurationManager.ConnectionStrings["custconn"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
               
                   int a;

                    string query = "Select MAX(CustomerID) from CustomerDetails_121815";
                   
                    SqlCommand cmd = new SqlCommand(query,connection);
                    cmd.Connection = connection;
 
         
               if (connection.State == ConnectionState.Closed)

                   connection.Open();

               SqlDataReader dr = cmd.ExecuteReader();
		  if (dr.Read())
            {                
                string val = dr[0].ToString();
                if (val == "")
                {
                    txtId.Text = "1";
                }
                else
                {
                    a = Convert.ToInt32(dr[0].ToString());
                    a = a + 1;
                    txtId.Text = a.ToString();
                }
            }
         }
               

        }
        
    }

