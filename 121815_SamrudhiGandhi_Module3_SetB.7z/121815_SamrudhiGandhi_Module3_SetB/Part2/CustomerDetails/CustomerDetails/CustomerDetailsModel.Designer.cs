﻿// Default code generation is disabled for model 'D:\Samrudhi\121815_SamrudhiGandhi_Module3_SetB\Part2\CustomerDetails\CustomerDetails\CustomerDetailsModel.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.