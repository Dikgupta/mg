﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomerDetails
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// /// Author:Samrudhi Gandhi
    /// Date Modified: 14th march 2017
    /// Version No: 1.0
    /// </summary>
    public partial class MainWindow : Window
    {
        # region Object
        Training_18Jan2017_TalwadeEntities1 obj = new Training_18Jan2017_TalwadeEntities1();
        CustomerDetails_121815 cust = new CustomerDetails_121815();
        #endregion

        public MainWindow()
        {
            InitializeComponent();
        }

        //Method for Display onclick event
        private void Display_Click(object sender, RoutedEventArgs e)
        {
            var query = from cust in obj.CustomerDetails_121815
                        where cust.Country =="India" && cust.City =="Mumbai"
                        orderby cust.City descending
                        select cust;

            Dgview.ItemsSource = query.ToList();
                     
        }


    }
}
