create table CustomerDetails_121815
(
	CustomerID int IDENTITY(1,1) primary key,
	CustomerName Varchar(30),
	Country varchar(20),
	City varchar(20) 
)

insert into CustomerDetails_121815(CustomerName,Country,City) values('Samrudhi','India','Mumbai')
insert into CustomerDetails_121815(CustomerName,Country,City) values('Sapna','India','Mumbai')
insert into CustomerDetails_121815(CustomerName,Country,City) values('Shilpa','Dubai','Kuwait')
insert into CustomerDetails_121815(CustomerName,Country,City) values('Sweta','India','Pune')
insert into CustomerDetails_121815(CustomerName,Country,City) values('Nisha','India','Mumbai')
insert into CustomerDetails_121815(CustomerName,Country,City) values('Amit','Dubai','Kuwait')
insert into CustomerDetails_121815(CustomerName,Country,City) values('Preshit','India','Pune')
insert into CustomerDetails_121815(CustomerName,Country,City) values('Ujwal','India','Mumbai')

select * from CustomerDetails_121815
where Country='India' and City='Mumbai'
order by city desc

select * from CustomerDetails_121815



