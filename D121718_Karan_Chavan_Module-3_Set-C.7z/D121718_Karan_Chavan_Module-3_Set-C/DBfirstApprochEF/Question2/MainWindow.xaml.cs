﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Question2
{
    /// <summary>
    /// WPF file for performing operation on order table
    /// Author: Mr. Karan Chavan
    /// Date Modified: 14th march 2017
    /// Version No:1.0
    /// Change Description:
    /// </summary>
    
    public partial class MainWindow : Window
    {
        MyEntity1 en = new MyEntity1();
      
        public MainWindow()
        {
            InitializeComponent();
        }

        //Button click event which is Displaying the record 
        //of ORders having the Order Quantity Greater than 500
       
        private void btnRecords_Click(object sender, RoutedEventArgs e)
        {
            //OrderTable_121718 order = new OrderTable_121718();
            var query = from a in en.OrderTable_121718
                        where a.OrderQuantity > 500
                        select a;
                     
                      datagrid.ItemsSource = query.ToList();
                      if (query == null) 
                      {
                          MessageBox.Show("No Record Over 500");
                      }    
        }
    }
}
