﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using Entity;
using Exception;
using BBMS.DAL;
namespace BBMS.BL
{
    public class BuybagsValidation
    {

        /// <summary>
        /// Program for validation of orders
        /// Author: Mr. Karan Chavan
        /// Date Modified: 14th march 2017
        /// Version No:1.0
        /// Change Description:
        /// </summary>
        /// 
        BuyBagsOperations operationObj = new BuyBagsOperations();
        public bool validateOrder(Buybags sObj)
        {
            bool ValidateShop = false;
            StringBuilder sb = new StringBuilder();
            if (sObj.OrderID.ToString().Length == 0)
            {
                ValidateShop = false;
                sb.Append(Environment.NewLine + "Order Id is Required");

            }
            if (sObj.CustomerID.ToString().Length == 0)
            {
                ValidateShop = false;
                sb.Append(Environment.NewLine + "Customer Id is Required");

            }
            if (sObj.OrderDate.ToString().Length == 0)
            {
                ValidateShop = false;
                sb.Append(Environment.NewLine + "Order Date is Required");

            }
            if (sObj.OrderDate > DateTime.Today)
            {
                ValidateShop = false;
                sb.Append(Environment.NewLine + "The order date cannot be greater than today");

            }
            if (sObj.ProductID.ToString().Length == 0)
            {
                ValidateShop = false;
                sb.Append(Environment.NewLine + "ProductID Id is Required");

            }
            if (sObj.OrderQuantity.ToString().Length == 0)
            {
                ValidateShop = false;
                sb.Append(Environment.NewLine + "Order Quantity is Required");
            }
            if (sObj.OrderQuantity.ToString().Length <= 0)
            {
                ValidateShop = false;
                sb.Append(Environment.NewLine + "Order Quantity Must be Greater than zero");

            }
            if (ValidateShop == false)
            {
                throw new BuyBagsException(sb.ToString());
            }
            return ValidateShop;


        }
        public bool AddOrderRecord(Buybags sObj)
        {
            bool OrderAdded = false;
            if (validateOrder(sObj))
                OrderAdded = operationObj.addOrderRecord(sObj);
            return OrderAdded;


        }
    }
}
