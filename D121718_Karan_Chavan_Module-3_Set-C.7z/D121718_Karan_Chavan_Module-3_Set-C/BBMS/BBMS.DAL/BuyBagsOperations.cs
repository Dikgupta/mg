﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exception;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
namespace BBMS.DAL
{
    public class BuyBagsOperations
    {
        /// <summary>
        /// DAL to Perform Shopping Operations
        /// Author: Mr. Karan Chavan
        /// Date Modified: 14th march 2017
        /// Version No:1.0
        /// Change Description:
        /// </summary>
        /// 


        SqlConnection connection;

        public BuyBagsOperations() {
            string connectionString = ConfigurationManager.ConnectionStrings["bagsconn"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        public bool addOrderRecord(Buybags obj)
        {
            try
            {
                bool orderAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddOrder", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@OrderID", obj.OrderID);
                cmdAdd.Parameters.AddWithValue("@CustomerID", obj.CustomerID);
                cmdAdd.Parameters.AddWithValue("@OrderDate", obj.OrderDate);
                cmdAdd.Parameters.AddWithValue("@OrderQuantity", obj.OrderQuantity);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                {
                    orderAdded = true;
                }
                return orderAdded;
            }
            catch (BuyBagsException) { throw; }
            catch (SqlException) { throw; }
            catch (SystemException) { throw; }
            finally { connection.Close(); }
        }
    }
}
