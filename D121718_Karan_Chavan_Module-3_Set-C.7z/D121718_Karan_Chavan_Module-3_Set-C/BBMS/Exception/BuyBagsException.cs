﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception
{/// <summary>
    /// Exception to Handle Shopping Information
    /// Author: Mr. Karan Chavan
    /// Date Modified: 14th march 2017
    /// Version No:1.0
    /// Change Description:
    /// </summary>
    /// 
    public class BuyBagsException : ApplicationException
    {
        public BuyBagsException() : base() { }
        public BuyBagsException(string message) : base(message) { }
    }
}
