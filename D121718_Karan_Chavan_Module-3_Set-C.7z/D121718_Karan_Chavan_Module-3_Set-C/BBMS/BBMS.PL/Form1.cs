﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Exception;
using System.Data.SqlClient;
using BBMS.DAL;
using BBMS.BL;
namespace BBMS.PL
{
    public partial class Form1 : Form
    {
        BuybagsValidation validationObj = new BuybagsValidation();
        public Form1()
        {
            InitializeComponent();
        }

       

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                Buybags   Obj = new Buybags();
                bool isNumber;
                int result;
              
                isNumber = int.TryParse(Cid.Text, out result);
                if (isNumber)
                    Obj.CustomerID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in Customer ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                bool DataAdded = validationObj.validateOrder(Obj);
                if (DataAdded)
                    MessageBox.Show("Order Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add Order record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (BuyBagsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
