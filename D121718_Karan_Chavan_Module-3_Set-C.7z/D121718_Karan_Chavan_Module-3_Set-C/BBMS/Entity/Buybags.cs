﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    /// <summary>
    /// Entity to store Shopping Information
    /// Author: Mr. Karan Chavan
    /// Date Modified: 14th march 2017
    /// Version No:1.0
    /// Change Description:
    /// </summary>

    public class Buybags
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }
        public DateTime OrderDate { get; set; }
        public int ProductID { get; set; }
        public int OrderQuantity { get; set; }
    }
}
